import { useState, useEffect } from 'react';

const categorias = [
  "Eléctricos",
  "Cañerías Agua",
  "Cañerías Gas",
  "Cañerías Aire",
  "Luminarias",
  "Ferretería",
  "Herramientas",
];

export default function App() {
  const [items, setItems] = useState(() => JSON.parse(localStorage.getItem('inventario')) || []);
  const [nuevo, setNuevo] = useState({ categoria: "", nombre: "", codigo: "", cantidad: 0, ubicacion: "", notas: "" });

  

  const exportarJSON = () => {
    const dataStr = JSON.stringify(items, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'inventario.json';
    link.click();
  };

  const exportarCSV = () => {
    const header = "Categoría,Nombre,Código,Cantidad,Ubicación,Notas\n";
    const rows = items.map(i => \`\${i.categoria},\${i.nombre},\${i.codigo},\${i.cantidad},\${i.ubicacion},\${i.notas}\`).join("\n");
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'inventario.csv';
    link.click();
  };


  
  const retirarItem = (id) => {
    const cantidad = prompt("¿Cuántos quiere retirar?");
    const nombre = quienRetira || prompt("¿Quién retira?");
    if (!cantidad || isNaN(cantidad)) return;
    const item = items.find(i => i.id === id);
    const nuevoHistorial = {
      id: Date.now(),
      fecha: new Date().toLocaleString(),
      nombre: item.nombre,
      codigo: item.codigo,
      cantidad: Number(cantidad),
      quien: nombre
    };
    setHistorial(prev => [nuevoHistorial, ...prev]);
    setItems(prev => prev.map(item => item.id === id
      ? { ...item, cantidad: item.cantidad - Number(cantidad), notas: item.notas + ` | Retiró: ${nombre}` }
      : item
    ));
  };
    


  const [busqueda, setBusqueda] = useState("");
  const [quienRetira, setQuienRetira] = useState("");


  const [historial, setHistorial] = useState([]);



  const exportarHistorialJSON = () => {
    const dataStr = JSON.stringify(historial, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'historial_retiros.json';
    link.click();
  };

  const exportarHistorialCSV = () => {
    const header = "Fecha,Quien,Nombre,Código,Cantidad\n";
    const rows = historial.map(h => \`\${h.fecha},\${h.quien},\${h.nombre},\${h.codigo},\${h.cantidad}\`).join("\n");
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'historial_retiros.csv';
    link.click();
  };

useEffect(() => {
    localStorage.setItem('inventario', JSON.stringify(items));
  }, [items]);

  const agregarItem = () => {
    if (!nuevo.nombre || !nuevo.categoria) return;
    setItems([...items, { ...nuevo, id: Date.now() }]);
    setNuevo({ categoria: "", nombre: "", codigo: "", cantidad: 0, ubicacion: "", notas: "" });
  };

  const eliminarItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  
  const itemsFiltrados = items.filter(item =>
    item.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
    item.codigo.toLowerCase().includes(busqueda.toLowerCase()) ||
    item.categoria.toLowerCase().includes(busqueda.toLowerCase()) ||
    item.ubicacion.toLowerCase().includes(busqueda.toLowerCase())
  );

return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Inventario de Materiales</h1>
      <div className="grid grid-cols-2 gap-2 mb-4">
        <select value={nuevo.categoria} onChange={e => setNuevo({ ...nuevo, categoria: e.target.value })} className="p-2 border rounded">
          <option value="">Categoría</option>
          {categorias.map(cat => <option key={cat}>{cat}</option>)}
        </select>
        <input placeholder="Nombre" value={nuevo.nombre} onChange={e => setNuevo({ ...nuevo, nombre: e.target.value })} className="p-2 border rounded" />
        <input placeholder="Código" value={nuevo.codigo} onChange={e => setNuevo({ ...nuevo, codigo: e.target.value })} className="p-2 border rounded" />
        <input type="number" placeholder="Cantidad" value={nuevo.cantidad} onChange={e => setNuevo({ ...nuevo, cantidad: Number(e.target.value) })} className="p-2 border rounded" />
        <input placeholder="Ubicación" value={nuevo.ubicacion} onChange={e => setNuevo({ ...nuevo, ubicacion: e.target.value })} className="p-2 border rounded" />
        <input placeholder="Notas" value={nuevo.notas} onChange={e => setNuevo({ ...nuevo, notas: e.target.value })} className="p-2 border rounded" />
      </div>
      <button onClick={agregarItem} className="bg-blue-600 text-white px-4 py-2 rounded">Agregar</button>
      <div className="flex gap-2 mt-4">
        <button onClick={exportarJSON} className="bg-green-600 text-white px-4 py-2 rounded">Exportar JSON</button>
        <button onClick={exportarCSV} className="bg-yellow-600 text-white px-4 py-2 rounded">Exportar CSV</button>
      </div>

      
      <div className="grid grid-cols-2 gap-2 mt-4 mb-4">
        <input type="text" placeholder="🔍 Buscar materiales..." value={busqueda} onChange={e => setBusqueda(e.target.value)} className="p-2 border rounded col-span-2" />
        <input placeholder="👤 Quién retira" value={quienRetira} onChange={e => setQuienRetira(e.target.value)} className="p-2 border rounded col-span-2" />
      </div>
<ul className="mt-4 space-y-2">
        {itemsFiltrados.map(item => (
          <li key={item.id} className="p-2 border rounded flex justify-between items-center">
            <div>
              <strong>{item.nombre}</strong> ({item.categoria}) - Cod: {item.codigo} - Cant: {item.cantidad}
              <br /><small>{item.ubicacion} | {item.notas}</small>
            </div>
            <div className="flex gap-2"><button onClick={() => retirarItem(item.id)} className="text-orange-600">Retirar</button><button onClick={() => eliminarItem(item.id)} className="text-red-600">Eliminar</button></div>
          </li>
        ))}
      </ul>
      <div className="flex gap-2 mt-2">
        <button onClick={exportarHistorialJSON} className="bg-green-700 text-white px-3 py-1 rounded text-sm">Exportar Historial JSON</button>
        <button onClick={exportarHistorialCSV} className="bg-yellow-700 text-white px-3 py-1 rounded text-sm">Exportar Historial CSV</button>
      </div>

    </div>
  );
}
